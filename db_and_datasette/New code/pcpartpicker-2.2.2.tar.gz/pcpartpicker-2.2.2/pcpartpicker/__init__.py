from .api import API

__name__ = ["pcpartpicker"]
__version__ = '2.2.2'
__author__ = 'Jonathan Vusich'
__email__ = 'jonathanvusich@gmail.com'
