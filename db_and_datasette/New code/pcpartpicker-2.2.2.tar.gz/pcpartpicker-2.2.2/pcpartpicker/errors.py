class UnsupportedRegion(Exception):
    pass


class UnsupportedPart(Exception):
    pass


class DifferentModel(Exception):
    pass
